
import ma.projet.util.HibernateUtil;
import org.hibernate.Session;


public class Test {
    public static void main(String[] args) {
        Session session  = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
    }
}
